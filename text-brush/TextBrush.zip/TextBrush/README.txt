TextBrush
by
Indra Gunawan
---------

Execute:
mvn clean test
mvn exec:java -Dexec.mainClass="mylab.cs.TextBrush"

Enjoy :)


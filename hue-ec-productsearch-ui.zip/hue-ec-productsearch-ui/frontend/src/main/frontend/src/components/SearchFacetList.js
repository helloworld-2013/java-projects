import React, { Component } from 'react';

import {
    Drawer,
    Checkbox,
    TextField,
    RaisedButton
} from 'material-ui';

export default class SearchFacetList extends Component {
    render() {
        return (
            <Drawer
                open={true}
                anchor="right"
            >
                <div style={{ textAlign: 'left' }}>
                    <h3>Color</h3>
                    <Checkbox label="Red" />
                    <Checkbox label="Green" />
                    <Checkbox label="Blue" />
                </div>

                <div style={{ textAlign: 'left' }}>
                    <h3>Price</h3>
                    <TextField style={{width:50}} />
                    &nbsp;-&nbsp;
                    <TextField style={{width:50}} />
                    &nbsp;
                    <RaisedButton label='Go' primary={true} />
                </div>
            </Drawer>
        );
    }
}
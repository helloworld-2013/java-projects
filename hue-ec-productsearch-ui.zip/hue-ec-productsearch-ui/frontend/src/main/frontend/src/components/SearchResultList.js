import React, { Component } from 'react';

export default class SearchResultList extends Component {

    render() {
        return (
            <div></div>
        );
    }
    
}
import React, { Component } from 'react';
import {
    GridList, 
    GridTile
} from 'material-ui/GridList';

const tilesData = [{
    img: './images/jeans_1.jpg',
    title: 'Nautica',
    price: 100
},{
    img: './images/jeans_2.jpg',
    title: 'Yoyeah',
    price: 150
},{
    img: './images/jeans_3.jpg',
    title: 'PajamaJeans',
    price: 200
},{
    img: './images/jeans_4.jpg',
    title: 'Wrangler',
    price: 250
}];

export default class SearchResultList extends Component {

    render() {
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-around' }}>
                <GridList style={{ display: 'flex', flexWrap: 'nowrap', overflowX: 'auto' }}>
                    {tilesData.map((tile) => (
                        <GridTile
                            title={tile.title}
                            subtitle={<span>$ <b>{tile.price}</b></span>}
                        >
                            <img src={tile.img} />
                        </GridTile>
                    ))}
                </GridList>
            </div>
        );
    }
    
}
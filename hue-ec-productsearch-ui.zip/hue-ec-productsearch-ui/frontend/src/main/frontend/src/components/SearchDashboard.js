import React, { Component } from 'react';

export default class SearchDashboard extends Component {

    render() {
        return (
            <div></div>
        );
    }

}
import React, { Component } from 'react';

import {
    Paper,
    TextField,
    RaisedButton,
    IconButton,
    IconMenu,
    MenuItem
} from 'material-ui';

import SortIcon from 'material-ui/svg-icons/content/sort';

import SearchResultList from './SearchResultList';
import SearchFacetList from './SearchFacetList';

export default class SearchDashboard extends Component {
    state = {
        sortByValue: '1'
    };

    handleSortByChange = (event, value) => {
        this.setState({
            sortByValue: value,
        });
    };

    render() {
        return (
            <div>
                <SearchFacetList />
                <Paper>
                    <TextField hintText='Enter your search' style={{width:400}} />
                    &nbsp;
                    <RaisedButton label='Go' primary={true} />
                    &nbsp;
                    <IconMenu
                        iconButtonElement={<IconButton><SortIcon /></IconButton>}
                        onChange={this.handleSortByChange}
                        value={this.state.sortByValue}
                    >
                        <MenuItem value="1" primaryText="Relevance" />
                        <MenuItem value="2" primaryText="Popular" />
                    </IconMenu>
                    <SearchResultList />
                </Paper>
            </div>
        );
    }

}